-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 04, 2021 at 03:34 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `laravel_data`
--

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(7, '2014_10_12_000000_create_users_table', 1),
(8, '2014_10_12_100000_create_password_resets_table', 1),
(9, '2019_08_19_000000_create_failed_jobs_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `region` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `item_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sales_channel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_priority` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_date` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ship_date` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `units_sold` double NOT NULL,
  `unit_price` double NOT NULL,
  `unit_cost` double NOT NULL,
  `total_revenue` double NOT NULL,
  `total_cost` double NOT NULL,
  `total_profit` double NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `region`, `country`, `item_type`, `sales_channel`, `order_priority`, `order_date`, `order_id`, `ship_date`, `units_sold`, `unit_price`, `unit_cost`, `total_revenue`, `total_cost`, `total_profit`, `email_verified_at`, `remember_token`, `created_at`, `updated_at`) VALUES
(127, 'Sub-Saharan Africa', 'Namibia', 'Household', 'Offline', 'M', '42247', '897751939', '42289', 3604, 668.27, 502.54, 2408445.08, 1811154.16, 597290.92, NULL, NULL, '2021-07-04 07:32:10', '2021-07-04 07:32:10'),
(128, 'Europe', 'Iceland', 'Baby Food', 'Online', 'H', '40502', '599480426', '40552', 8435, 255.28, 159.42, 2153286.8, 1344707.7, 808579.1, NULL, NULL, '2021-07-04 07:32:10', '2021-07-04 07:32:10'),
(129, 'Europe', 'Russia', 'Meat', 'Online', 'L', '42908', '538911855', '42911', 4848, 421.89, 364.69, 2045322.72, 1768017.12, 277305.6, NULL, NULL, '2021-07-04 07:32:10', '2021-07-04 07:32:10'),
(130, 'Europe', 'Moldova ', 'Meat', 'Online', 'L', '40967', '459845054', '40988', 7225, 421.89, 364.69, 3048155.25, 2634885.25, 413270, NULL, NULL, '2021-07-04 07:32:10', '2021-07-04 07:32:10'),
(131, 'Europe', 'Malta', 'Cereal', 'Online', 'M', '40402', '626391351', '40434', 1975, 205.7, 117.11, 406257.5, 231292.25, 174965.25, NULL, NULL, '2021-07-04 07:32:10', '2021-07-04 07:32:10'),
(132, 'Asia', 'Indonesia', 'Meat', 'Online', 'H', '40410', '472974574', '40417', 2542, 421.89, 364.69, 1072444.38, 927041.98, 145402.4, NULL, NULL, '2021-07-04 07:32:10', '2021-07-04 07:32:10'),
(133, 'Sub-Saharan Africa', 'Djibouti', 'Household', 'Online', 'M', '40577', '854331052', '40605', 4398, 668.27, 502.54, 2939051.46, 2210170.92, 728880.54, NULL, NULL, '2021-07-04 07:32:10', '2021-07-04 07:32:10'),
(134, 'Europe', 'Greece', 'Household', 'Online', 'L', '42258', '895509612', '42273', 49, 668.27, 502.54, 32745.23, 24624.46, 8120.77, NULL, NULL, '2021-07-04 07:32:10', '2021-07-04 07:32:10'),
(135, 'Sub-Saharan Africa', 'Cameroon', 'Cosmetics', 'Offline', 'M', '41670', '241871583', '41674', 4031, 437.2, 263.33, 1762353.2, 1061483.23, 700869.97, NULL, NULL, '2021-07-04 07:32:10', '2021-07-04 07:32:10'),
(136, 'Sub-Saharan Africa', 'Nigeria', 'Cosmetics', 'Online', 'C', '42329', '409090793', '42345', 7911, 437.2, 263.33, 3458689.2, 2083203.63, 1375485.57, NULL, NULL, '2021-07-04 07:32:10', '2021-07-04 07:32:10'),
(137, 'Sub-Saharan Africa', 'Senegal', 'Fruits', 'Offline', 'M', '42611', '733153569', '42648', 5288, 9.33, 6.92, 49337.04, 36592.96, 12744.08, NULL, NULL, '2021-07-04 07:32:10', '2021-07-04 07:32:10'),
(138, 'Middle East and North Africa', 'Afghanistan', 'Cosmetics', 'Offline', 'L', '42664', '620358741', '42705', 6792, 437.2, 263.33, 2969462.4, 1788537.36, 1180925.04, NULL, NULL, '2021-07-04 07:32:10', '2021-07-04 07:32:10'),
(139, 'Asia', 'India', 'Vegetables', 'Online', 'C', '40258', '897317636', '40273', 5084, 154.06, 90.93, 783241.04, 462288.12, 320952.92, NULL, NULL, '2021-07-04 07:32:10', '2021-07-04 07:32:10'),
(140, 'Middle East and North Africa', 'Lebanon', 'Vegetables', 'Online', 'L', '40466', '660954082', '40501', 9855, 154.06, 90.93, 1518261.3, 896115.15, 622146.15, NULL, NULL, '2021-07-04 07:32:10', '2021-07-04 07:32:10');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=141;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
