<?php
   
namespace App\Imports;
   
use App\User;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
    
class UsersImport implements ToModel, WithHeadingRow
{
    /**
    * @param array $row
    *
    * @return \Illuminate\Database\Eloquent\Model|null
    */
    public function model(array $row)
    {
        return new User([
            'region'         => $row['region'],
            'country'        => $row['country'],
            'item_type'      => $row['item_type'], 
            'sales_channel'  => $row['sales_channel'], 
            'order_priority' => $row['order_priority'], 
            'order_date'     => $row['order_date'], 
            'order_id'       => $row['order_id'], 
            'ship_date'      => $row['ship_date'], 
            'units_sold'     => $row['units_sold'], 
            'unit_price'     => $row['unit_price'], 
            'unit_cost'      => $row['unit_cost'],
            'total_revenue'  => $row['total_revenue'],
            'total_cost'     => $row['total_cost'],
            'total_profit'   => $row['total_profit'], 
         
        ]);
    }
}