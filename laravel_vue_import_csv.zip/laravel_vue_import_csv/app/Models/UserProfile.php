<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\UserProfile;

class UserProfile extends Model
{

	 protected $table = 'profiles';
    protected $fillable = [
       'fname','lname','email','mobile','position','team','nid','qualification'
    ];

   

    public function users()
    {
        return $this->belongsToMany(User::class);
    }
}
