<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->string('region');
			$table->string('country');
			$table->string('item_type');
			$table->string('sales_channel');
			$table->string('order_priority');
			$table->string('order_date');
            $table->string('order_id');
            $table->string('ship_date');
            $table->double('units_sold');
            $table->double('unit_price');
            $table->double('unit_cost');
            $table->double('total_revenue');
            $table->double('total_cost');
            $table->double('total_profit');
            $table->timestamp('email_verified_at')->nullable();
            $table->rememberToken();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
