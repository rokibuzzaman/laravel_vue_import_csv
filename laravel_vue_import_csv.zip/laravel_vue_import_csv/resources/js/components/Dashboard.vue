<template>
   <div class="row">
      <div class="form-row">
        <div class="col-md-12">
          <label class="form-control-label"  for="input-file-import">Upload Excel File</label>
          <input type="file" class="form-control" :class="{ ' is-invalid' : error.message }" id="input-file-import" name="import_file" ref="import_file"  @change="onFileChange">
          <div v-if="error.message" class="invalid-feedback">
          <p>The import file field is required</p>
          </div>
          </br>
          <input class="form-control" name="upload" type="submit"  @click.prevent="proceedAction">
        </div>
      </div>
   </div>
</template>
<script>
  export default {
     data() {
        return {
          error: {},
          import_file: '',
        }
      },
      methods: {
         onFileChange(e) {
        this.import_file = e.target.files[0];
    },

    proceedAction() {
        let formData = new FormData();
        formData.append('import_file', this.import_file);

          axios.post('import', formData, {
              headers: { 'content-type': 'multipart/form-data' }
            })
            .then(response => {
                if(response.status === 200) {
                 $('#input-file-import').val(''); 
                Swal.fire(
                   
                    'File Upload Successfully!',
                    'success'
                  )
                  // codes here after the file is upload successfully
                }
            })
            .catch(error => {
                Swal.fire(
                   
                    'File Not Upload Successfully!',
                    'success'
                  )

                // code here when an upload is not valid
                this.uploading = false
                this.error = error.response.data
                console.log('check error: ', this.error)
            });
        },
      }
  }
</script>