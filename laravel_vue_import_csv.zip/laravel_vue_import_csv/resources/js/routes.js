export default [

    { path: '*', component: require('./components/Dashboard.vue').default }
];
