<!DOCTYPE html>
<html>
<head>
    <title>Laravel 5.8 Import Export Excel to database Example - ItSolutionStuff.com</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css" />
     <link href="<?php echo e(mix('css/app.css')); ?>" type="text/css" rel="stylesheet" />
</head>
<body>
     <!-- <div id="app"><router-view></router-view></div> -->
   
<!-- <div class="container" id="app">
     
    <div class="card bg-light mt-3">
        <div class="card-header">
            Laravel 5.8 Import Export Excel to database Example - ItSolutionStuff.com
        </div>
        <div class="card-body">
            
        </div>
    </div>

    <router-view></router-view>
</div> -->

  <div id="app">

   
<div class="container">
    <div class="card bg-light mt-3">
        <div class="card-header">
           Import Data
        </div>
        <div class="card-body">
         
            <router-view></router-view>
        </div>
    </div>
   
  
</div>

</div>
 <script src="<?php echo e(mix('js/app.js')); ?>" type="text/javascript"></script>
   
</body>
</html><?php /**PATH E:\project\htdocs\importtest\resources\views/welcome.blade.php ENDPATH**/ ?>